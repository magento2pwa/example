const { Targetables } = require('@magento/pwa-buildpack');
module.exports = targets => {
    const targetables = Targetables.using(targets);
    const ProductDetails = targetables.reactComponent(
        '@magento/venia-ui/lib/components/ProductFullDetail/productFullDetail.js'
    );
    const LinkedProducts = ProductDetails.addImport(
        "LinkedProducts from '/src/components/LinkedProducts/linkedProducts'"
    );
    ProductDetails
        .insertAfterJSX('<Form />', `<${LinkedProducts} />`)
        .setJSXProps('LinkedProducts', {
            'classes': '{classes}',
            'productDetails': '{productDetails}',
            'options': '{options}',
            'mediaGalleryEntries': '{mediaGalleryEntries}'
        });
};