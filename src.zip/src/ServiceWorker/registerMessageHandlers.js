export {
    registerImagePreFetchHandler as default
} from './Utilities/imageCacheHandler';
